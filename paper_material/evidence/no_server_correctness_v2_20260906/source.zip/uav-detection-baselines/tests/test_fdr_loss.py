from __future__ import annotations

import math

import pytest
import torch
from torch import nn
from ultralytics.models.utils.loss import RTDETRDetectionLoss

from src.fdr_math import bbox2distance, fine_grained_localization_loss
from src.fdr_loss import (
    FDRDetectionLoss,
    adjacent_bin_fgl,
    edge_adaptive_fgl_weights,
    layerwise_reliability_shrinkage,
    representable_fgl_targets,
    stock_loss_subtotal,
)


def _mixed_batch() -> dict:
    return {
        "cls": torch.tensor([1], dtype=torch.long),
        "bboxes": torch.tensor([[0.52, 0.48, 0.18, 0.22]], dtype=torch.float32),
        "gt_groups": [1, 0],
    }


def _empty_batch(batch_size: int = 2) -> dict:
    return {
        "cls": torch.empty(0, dtype=torch.long),
        "bboxes": torch.empty(0, 4, dtype=torch.float32),
        "gt_groups": [0] * batch_size,
    }


def _matches_with_one_positive() -> list[tuple[torch.Tensor, torch.Tensor]]:
    return [
        (torch.tensor([1], dtype=torch.long), torch.tensor([0], dtype=torch.long)),
        (torch.empty(0, dtype=torch.long), torch.empty(0, dtype=torch.long)),
    ]


def _empty_matches(batch_size: int = 2) -> list[tuple[torch.Tensor, torch.Tensor]]:
    return [
        (torch.empty(0, dtype=torch.long), torch.empty(0, dtype=torch.long))
        for _ in range(batch_size)
    ]


def _predictions(
    *, layers: int = 3, batch: int = 2, queries: int = 4, classes: int = 3
) -> tuple[torch.Tensor, torch.Tensor]:
    generator = torch.Generator().manual_seed(3407)
    boxes = torch.rand((layers, batch, queries, 4), generator=generator)
    boxes[..., 2:] = boxes[..., 2:] * 0.25 + 0.05
    scores = torch.randn((layers, batch, queries, classes), generator=generator)
    return boxes, scores


def _corner_logits(
    *, layers: int = 3, batch: int = 2, queries: int = 4
) -> torch.Tensor:
    generator = torch.Generator().manual_seed(901)
    return torch.randn(
        (layers, batch, queries, 4 * 33), generator=generator, requires_grad=True
    )


def _two_positive_fgl_inputs() -> tuple[
    torch.Tensor,
    torch.Tensor,
    torch.Tensor,
    list[tuple[torch.Tensor, torch.Tensor]],
]:
    targets = torch.tensor(
        [[0.30, 0.30, 0.20, 0.20], [0.70, 0.70, 0.20, 0.20]],
        dtype=torch.float32,
    )
    predictions = torch.tensor(
        [
            [
                [0.30, 0.30, 0.20, 0.20],
                [0.78, 0.78, 0.20, 0.20],
            ],
            [[0.50, 0.50, 0.10, 0.10], [0.50, 0.50, 0.10, 0.10]],
        ],
        dtype=torch.float32,
    )
    references = predictions.detach().clone()
    matches = [
        (torch.tensor([0, 1]), torch.tensor([0, 1])),
        (torch.empty(0, dtype=torch.long), torch.empty(0, dtype=torch.long)),
    ]
    return predictions, references, targets, matches


class CountingMatcher(nn.Module):
    def __init__(self, matches: list[tuple[torch.Tensor, torch.Tensor]]) -> None:
        super().__init__()
        self.matches = matches
        self.calls = 0

    def forward(self, *args, **kwargs):
        self.calls += 1
        return [(source.clone(), target.clone()) for source, target in self.matches]


def test_lrs_disabled_and_final_layer_are_exact_legacy_paths() -> None:
    quality = torch.tensor([0.0, 0.2, 0.8, 1.0], requires_grad=True)
    batch_indices = torch.tensor([0, 0, 1, 1])

    disabled = layerwise_reliability_shrinkage(
        quality,
        batch_indices,
        layer_index=0,
        num_layers=6,
        alpha0=0.0,
    )
    final = layerwise_reliability_shrinkage(
        quality,
        batch_indices,
        layer_index=5,
        num_layers=6,
        alpha0=0.25,
    )

    torch.testing.assert_close(disabled, quality.detach(), rtol=0, atol=0)
    torch.testing.assert_close(final, quality.detach(), rtol=0, atol=0)
    assert disabled.dtype == quality.dtype
    assert final.dtype == quality.dtype
    assert disabled.requires_grad is False
    assert final.requires_grad is False


def test_lrs_conserves_each_image_sum_and_shrinks_within_image_variance() -> None:
    quality = torch.tensor([0.0, 0.2, 0.8, 0.4, 1.0], dtype=torch.float16)
    batch_indices = torch.tensor([0, 0, 0, 1, 1])

    weights = layerwise_reliability_shrinkage(
        quality,
        batch_indices,
        layer_index=0,
        num_layers=6,
        alpha0=0.25,
    )

    assert weights.dtype == torch.float32
    for batch_index in (0, 1):
        mask = batch_indices == batch_index
        torch.testing.assert_close(
            weights[mask].sum(),
            quality[mask].float().sum(),
            rtol=0,
            atol=2e-6,
        )
        assert weights[mask].var(unbiased=False) < quality[mask].float().var(
            unbiased=False
        )
        assert torch.equal(
            torch.argsort(weights[mask]), torch.argsort(quality[mask].float())
        )


def test_lrs_never_mixes_images_and_handles_empty_or_singleton_groups() -> None:
    quality = torch.tensor([0.0, 1.0, 0.25])
    batch_indices = torch.tensor([0, 0, 1])
    weights = layerwise_reliability_shrinkage(
        quality,
        batch_indices,
        layer_index=2,
        num_layers=6,
        alpha0=0.25,
    )

    assert weights[0] < weights[1]
    torch.testing.assert_close(weights[2], quality[2], rtol=0, atol=0)
    empty = layerwise_reliability_shrinkage(
        quality[:0],
        batch_indices[:0],
        layer_index=0,
        num_layers=6,
        alpha0=0.25,
    )
    assert empty.shape == quality[:0].shape
    assert torch.isfinite(empty).all()


def test_lrs_representability_mask_preserves_excluded_weights_exactly() -> None:
    quality = torch.tensor([0.0, 0.2, 0.8, 1.0])
    batch_indices = torch.zeros(4, dtype=torch.long)
    eligible = torch.tensor([False, True, True, False])

    weights = layerwise_reliability_shrinkage(
        quality,
        batch_indices,
        layer_index=0,
        num_layers=6,
        alpha0=0.25,
        eligible_mask=eligible,
    )

    torch.testing.assert_close(weights[~eligible], quality[~eligible], rtol=0, atol=0)
    torch.testing.assert_close(
        weights[eligible].sum(), quality[eligible].sum(), rtol=0, atol=2e-6
    )
    assert weights[1] > quality[1]
    assert weights[2] < quality[2]


def test_representable_fgl_targets_exclude_any_boundary_edge() -> None:
    target_indices = torch.tensor(
        [[0.0, 1.0, 2.0, 3.0], [1.0, 2.0, 30.0, 30.9]]
    )

    mask = representable_fgl_targets(target_indices.reshape(-1))

    assert torch.equal(mask, torch.tensor([False, True]))


@pytest.mark.parametrize(
    ("layer_index", "num_layers", "alpha0", "batch_indices", "message"),
    [
        (-1, 6, 0.25, torch.tensor([0, 0]), "layer_index"),
        (6, 6, 0.25, torch.tensor([0, 0]), "layer_index"),
        (0, 1, 0.25, torch.tensor([0, 0]), "num_layers"),
        (0, 6, -0.1, torch.tensor([0, 0]), "alpha0"),
        (0, 6, 1.0, torch.tensor([0, 0]), "alpha0"),
        (0, 6, 0.25, torch.tensor([0]), "batch_indices"),
    ],
)
def test_lrs_rejects_invalid_contracts(
    layer_index: int,
    num_layers: int,
    alpha0: float,
    batch_indices: torch.Tensor,
    message: str,
) -> None:
    with pytest.raises(ValueError, match=message):
        layerwise_reliability_shrinkage(
            torch.tensor([0.1, 0.9]),
            batch_indices,
            layer_index=layer_index,
            num_layers=num_layers,
            alpha0=alpha0,
        )


def test_lrs_rejects_a_mismatched_eligibility_mask() -> None:
    with pytest.raises(ValueError, match="eligible_mask"):
        layerwise_reliability_shrinkage(
            torch.tensor([0.1, 0.9]),
            torch.tensor([0, 0]),
            layer_index=0,
            num_layers=6,
            alpha0=0.25,
            eligible_mask=torch.tensor([True]),
        )


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA is unavailable")
def test_lrs_accepts_stock_cpu_match_indices_for_cuda_quality() -> None:
    quality = torch.tensor([0.1, 0.9], device="cuda:0")
    weights = layerwise_reliability_shrinkage(
        quality,
        torch.tensor([0, 0]),
        layer_index=0,
        num_layers=6,
        alpha0=0.25,
        eligible_mask=torch.tensor([True, True], device="cuda:0"),
    )

    assert weights.device == quality.device
    torch.testing.assert_close(weights.sum(), quality.sum(), rtol=0, atol=2e-6)


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA is unavailable")
def test_lrs_conserves_large_mixed_cuda_groups_within_gate_tolerance() -> None:
    quality = torch.rand(300, generator=torch.Generator().manual_seed(17)).cuda()
    batch_indices = torch.cat(
        (torch.zeros(150, dtype=torch.long), torch.ones(150, dtype=torch.long))
    )
    eligible = torch.arange(300, device="cuda:0") % 5 != 0

    weights = layerwise_reliability_shrinkage(
        quality,
        batch_indices,
        layer_index=0,
        num_layers=6,
        alpha0=0.25,
        eligible_mask=eligible,
    )

    cuda_batch_indices = batch_indices.cuda()
    for batch_index in (0, 1):
        mask = cuda_batch_indices == batch_index
        error = (weights[mask].double().sum() - quality[mask].double().sum()).abs()
        assert float(error) <= 2e-6


def test_fgl_zero_preserves_every_stock_key_value_and_stock_subtotal_exact() -> None:
    boxes, scores = _predictions(layers=7)
    batch = _mixed_batch()
    matches = _matches_with_one_positive()

    stock = RTDETRDetectionLoss(nc=3, use_vfl=True)
    stock.matcher = CountingMatcher(matches)
    stock_losses = stock((boxes, scores), batch)

    pre_boxes = boxes[1].detach().clone().requires_grad_(True)
    criterion = FDRDetectionLoss(
        nc=3, use_vfl=True, fgl_weight=0.0, supervise_pre_boxes=True
    )
    actual = criterion(
        (boxes, scores),
        batch,
        normal_match_indices=[matches] * 7,
        pre_boxes=pre_boxes,
    )

    assert set(stock_losses).issubset(actual)
    for key, expected in stock_losses.items():
        torch.testing.assert_close(actual[key], expected, rtol=0, atol=0)
    torch.testing.assert_close(
        stock_loss_subtotal(actual), stock_loss_subtotal(stock_losses), rtol=0, atol=0
    )
    assert {"loss_bbox_pre", "loss_giou_pre"}.issubset(actual)
    assert not any("class_pre" in key or "pre_class" in key for key in actual)
    assert not any("fgl" in key for key in actual)


def test_fgl_zero_with_distribution_inputs_has_isolated_zero_keys() -> None:
    boxes, scores = _predictions(layers=2)
    matches = _matches_with_one_positive()
    corners = _corner_logits(layers=1)
    criterion = FDRDetectionLoss(
        nc=3, use_vfl=True, fgl_weight=0.0, supervise_pre_boxes=False
    )

    losses = criterion(
        (boxes, scores),
        _mixed_batch(),
        normal_match_indices=[matches, matches],
        corner_logits=corners,
        pre_boxes=boxes[0].detach().clone(),
    )

    assert {"loss_fgl", "loss_fgl_aux"}.issubset(losses)
    torch.testing.assert_close(losses["loss_fgl"], torch.zeros_like(losses["loss_fgl"]))
    torch.testing.assert_close(
        losses["loss_fgl_aux"], torch.zeros_like(losses["loss_fgl_aux"])
    )


def test_normal_fgl_skips_encoder_and_aligns_six_decoder_layers() -> None:
    stock_boxes, stock_scores = _predictions(layers=7)
    corners = _corner_logits(layers=6)
    matches = _matches_with_one_positive()
    criterion = FDRDetectionLoss(nc=3, use_vfl=True, fgl_weight=0.15)

    losses = criterion(
        (stock_boxes, stock_scores),
        _mixed_batch(),
        normal_match_indices=[matches] * 7,
        corner_logits=corners,
        pre_boxes=stock_boxes[1].detach().clone(),
    )
    (losses["loss_fgl"] + losses["loss_fgl_aux"]).backward()

    assert corners.grad is not None and torch.isfinite(corners.grad).all()
    assert criterion.stock_match_calls == 0
    assert criterion.fgl_extra_match_calls == 0


def test_adjacent_bin_fgl_matches_pinned_primitive_exactly() -> None:
    logits = torch.tensor(
        [
            [math.log(2.0), math.log(3.0), math.log(5.0)],
            [math.log(7.0), math.log(11.0), math.log(13.0)],
        ],
        requires_grad=True,
    )
    left = torch.tensor([0.0, 1.0])
    weight_right = torch.tensor([0.25, 0.60])
    weight_left = 1.0 - weight_right
    matched_iou = torch.tensor([0.5, 0.8], requires_grad=True)

    actual = adjacent_bin_fgl(
        logits,
        left,
        weight_left,
        weight_right,
        matched_iou,
        avg_factor=2.5,
    )
    expected = fine_grained_localization_loss(
        logits,
        left,
        weight_right,
        weight_left,
        weight=matched_iou.detach(),
        avg_factor=2.5,
    )

    torch.testing.assert_close(actual, expected, rtol=0, atol=0)
    actual.backward()
    assert logits.grad is not None and torch.isfinite(logits.grad).all()
    assert matched_iou.grad is None


def test_edge_adaptive_fgl_weights_reduce_to_repeated_iou_for_equal_edges() -> None:
    logits = torch.tensor(
        [[2.0, 0.0, -2.0]] * 4,
        requires_grad=True,
    )
    target_indices = torch.zeros(4)
    left_weight = torch.ones(4)
    right_weight = torch.zeros(4)
    edge_iou = torch.full((4,), 0.8, requires_grad=True)

    weights = edge_adaptive_fgl_weights(
        logits,
        target_indices,
        left_weight,
        right_weight,
        edge_iou,
    )

    torch.testing.assert_close(weights, edge_iou.detach(), rtol=0, atol=0)
    assert weights.shape == edge_iou.shape
    assert weights.requires_grad is False


def test_edge_adaptive_fgl_weights_prioritize_the_harder_edge() -> None:
    logits = torch.tensor(
        [
            [-3.0, 3.0, 0.0],
            [3.0, 0.0, -3.0],
            [3.0, 0.0, -3.0],
            [3.0, 0.0, -3.0],
        ],
        requires_grad=True,
    )
    target_indices = torch.zeros(4)
    left_weight = torch.ones(4)
    right_weight = torch.zeros(4)
    edge_iou = torch.full((4,), 0.75)

    weights = edge_adaptive_fgl_weights(
        logits,
        target_indices,
        left_weight,
        right_weight,
        edge_iou,
    )
    modulation = weights / edge_iou

    assert weights[0] > weights[1:].max()
    assert torch.all(modulation >= 0.5)
    assert torch.all(modulation <= 2.0)
    assert weights.requires_grad is False


def test_fdr_criterion_declares_edge_adaptive_fgl_as_an_opt_in_contract() -> None:
    stock = FDRDetectionLoss(nc=3, use_vfl=True)
    ace = FDRDetectionLoss(nc=3, use_vfl=True, edge_adaptive_fgl=True)
    lrs = FDRDetectionLoss(
        nc=3, use_vfl=True, reliability_shrinkage_alpha=0.25
    )

    assert stock.edge_adaptive_fgl is False
    assert stock.reliability_shrinkage_alpha == 0.0
    assert ace.edge_adaptive_fgl is True
    assert lrs.reliability_shrinkage_alpha == 0.25


def test_lrs_and_edge_adaptive_fgl_are_mutually_exclusive() -> None:
    with pytest.raises(ValueError, match="mutually exclusive"):
        FDRDetectionLoss(
            nc=3,
            use_vfl=True,
            edge_adaptive_fgl=True,
            reliability_shrinkage_alpha=0.25,
        )


def test_lrs_zero_matches_legacy_fgl_loss_and_gradient_exactly() -> None:
    predictions, references, targets, matches = _two_positive_fgl_inputs()
    base_logits = torch.randn((2, 2, 4 * 33), generator=torch.Generator().manual_seed(7))
    legacy_logits = base_logits.detach().clone().requires_grad_(True)
    disabled_logits = base_logits.detach().clone().requires_grad_(True)
    legacy = FDRDetectionLoss(nc=3, use_vfl=True)
    disabled = FDRDetectionLoss(
        nc=3, use_vfl=True, reliability_shrinkage_alpha=0.0
    )

    legacy_loss = legacy._fgl_for_layer(
        legacy_logits,
        predictions,
        references,
        targets,
        matches,
        layer_index=0,
        num_layers=6,
        apply_reliability_shrinkage=True,
    )
    disabled_loss = disabled._fgl_for_layer(
        disabled_logits,
        predictions,
        references,
        targets,
        matches,
        layer_index=0,
        num_layers=6,
        apply_reliability_shrinkage=True,
    )
    legacy_loss.backward()
    disabled_loss.backward()

    torch.testing.assert_close(disabled_loss, legacy_loss, rtol=0, atol=0)
    torch.testing.assert_close(
        disabled_logits.grad, legacy_logits.grad, rtol=0, atol=0
    )


def test_lrs_changes_shallow_normal_fgl_but_not_final_layer_or_dn() -> None:
    predictions, references, targets, matches = _two_positive_fgl_inputs()
    logits = torch.randn((2, 2, 4 * 33), generator=torch.Generator().manual_seed(11))
    clean = FDRDetectionLoss(nc=3, use_vfl=True)
    lrs = FDRDetectionLoss(
        nc=3, use_vfl=True, reliability_shrinkage_alpha=0.25
    )

    clean_shallow = clean._fgl_for_layer(
        logits,
        predictions,
        references,
        targets,
        matches,
        layer_index=0,
        num_layers=6,
        apply_reliability_shrinkage=True,
    )
    lrs_shallow = lrs._fgl_for_layer(
        logits,
        predictions,
        references,
        targets,
        matches,
        layer_index=0,
        num_layers=6,
        apply_reliability_shrinkage=True,
    )
    clean_final = clean._fgl_for_layer(
        logits,
        predictions,
        references,
        targets,
        matches,
        layer_index=5,
        num_layers=6,
        apply_reliability_shrinkage=True,
    )
    lrs_final = lrs._fgl_for_layer(
        logits,
        predictions,
        references,
        targets,
        matches,
        layer_index=5,
        num_layers=6,
        apply_reliability_shrinkage=True,
    )
    lrs_dn = lrs._fgl_for_layer(
        logits,
        predictions,
        references,
        targets,
        matches,
        layer_index=0,
        num_layers=6,
        apply_reliability_shrinkage=False,
    )

    assert not torch.equal(lrs_shallow, clean_shallow)
    torch.testing.assert_close(lrs_final, clean_final, rtol=0, atol=0)
    torch.testing.assert_close(lrs_dn, clean_shallow, rtol=0, atol=0)


def test_fgl_target_reference_is_detached_from_preliminary_box() -> None:
    boxes, scores = _predictions(layers=3)
    batch = _mixed_batch()
    layer_zero = _matches_with_one_positive()
    main_layer = [
        (torch.tensor([0]), torch.tensor([0])),
        (torch.empty(0, dtype=torch.long), torch.empty(0, dtype=torch.long)),
    ]
    pre_boxes = boxes[0].detach().clone().requires_grad_(True)
    corners = _corner_logits(layers=2)
    criterion = FDRDetectionLoss(
        nc=3, use_vfl=True, fgl_weight=0.15, supervise_pre_boxes=False
    )

    losses = criterion(
        (boxes, scores),
        batch,
        normal_match_indices=[layer_zero, layer_zero, main_layer],
        corner_logits=corners,
        pre_boxes=pre_boxes,
    )
    (losses["loss_fgl"] + losses["loss_fgl_aux"]).backward()

    assert pre_boxes.grad is None
    assert corners.grad is not None and torch.isfinite(corners.grad).all()


def test_pre_box_supervision_uses_layer_zero_assignment_and_has_finite_gradient() -> None:
    boxes, scores = _predictions(layers=3)
    batch = _mixed_batch()
    encoder = [
        (torch.tensor([0]), torch.tensor([0])),
        (torch.empty(0, dtype=torch.long), torch.empty(0, dtype=torch.long)),
    ]
    decoder_layer_zero = _matches_with_one_positive()
    pre_boxes = boxes[0].detach().clone().requires_grad_(True)
    criterion = FDRDetectionLoss(
        nc=3, use_vfl=True, fgl_weight=0.0, supervise_pre_boxes=True
    )

    losses = criterion(
        (boxes, scores),
        batch,
        normal_match_indices=[encoder, decoder_layer_zero, encoder],
        pre_boxes=pre_boxes,
    )
    (losses["loss_bbox_pre"] + losses["loss_giou_pre"]).backward()

    assert pre_boxes.grad is not None
    assert torch.isfinite(pre_boxes.grad).all()
    assert pre_boxes.grad[0, 1].abs().sum() > 0
    assert torch.equal(pre_boxes.grad[0, 0], torch.zeros(4))
    assert not any("class" in key and "pre" in key for key in losses)


def test_fgl_and_pre_losses_reuse_stock_normal_and_fixed_dn_assignments() -> None:
    layers, batch_size, queries = 3, 2, 4
    boxes, scores = _predictions(layers=layers, batch=batch_size, queries=queries)
    matches = _matches_with_one_positive()
    matcher = CountingMatcher(matches)
    criterion = FDRDetectionLoss(
        nc=3, use_vfl=True, fgl_weight=0.15, supervise_pre_boxes=True
    )
    criterion.matcher = matcher

    dn_queries = 2
    generator = torch.Generator().manual_seed(77)
    dn_boxes = torch.rand((layers, batch_size, dn_queries, 4), generator=generator)
    dn_boxes[..., 2:] = dn_boxes[..., 2:] * 0.2 + 0.05
    dn_scores = torch.randn((layers, batch_size, dn_queries, 3), generator=generator)
    dn_meta = {
        "dn_pos_idx": [torch.tensor([0]), torch.empty(0, dtype=torch.long)],
        "dn_num_group": 1,
    }
    pre_boxes = boxes[0].detach().clone().requires_grad_(True)
    dn_pre_boxes = dn_boxes[0].detach().clone().requires_grad_(True)

    losses = criterion(
        (boxes, scores),
        _mixed_batch(),
        dn_bboxes=dn_boxes,
        dn_scores=dn_scores,
        dn_meta=dn_meta,
        corner_logits=_corner_logits(layers=layers - 1),
        pre_boxes=pre_boxes,
        dn_corner_logits=_corner_logits(
            layers=layers, batch=batch_size, queries=dn_queries
        ),
        dn_pre_boxes=dn_pre_boxes,
    )

    assert matcher.calls == layers
    assert criterion.stock_match_calls == layers
    assert criterion.fgl_extra_match_calls == 0
    assert {
        "loss_fgl",
        "loss_fgl_aux",
        "loss_fgl_dn",
        "loss_fgl_aux_dn",
        "loss_bbox_pre",
        "loss_giou_pre",
        "loss_bbox_pre_dn",
        "loss_giou_pre_dn",
    }.issubset(losses)
    assert not any(
        forbidden in key.lower()
        for key in losses
        for forbidden in ("ddf", "teacher", "lqe", "go_lsd", "gate")
    )
    (
        losses["loss_bbox_pre"]
        + losses["loss_giou_pre"]
        + losses["loss_bbox_pre_dn"]
        + losses["loss_giou_pre_dn"]
    ).backward()
    assert pre_boxes.grad is not None and torch.isfinite(pre_boxes.grad).all()
    assert dn_pre_boxes.grad is not None and torch.isfinite(dn_pre_boxes.grad).all()
    assert matcher.calls == layers


def test_disables_only_extra_dn_fdr_supervision() -> None:
    layers, batch_size, queries = 3, 2, 4
    boxes, scores = _predictions(layers=layers, batch=batch_size, queries=queries)
    matches = _matches_with_one_positive()
    criterion = FDRDetectionLoss(
        nc=3,
        use_vfl=True,
        fgl_weight=0.15,
        supervise_pre_boxes=True,
        supervise_dn_fdr=False,
    )
    criterion.matcher = CountingMatcher(matches)

    dn_queries = 2
    generator = torch.Generator().manual_seed(91)
    dn_boxes = torch.rand((layers, batch_size, dn_queries, 4), generator=generator)
    dn_boxes[..., 2:] = dn_boxes[..., 2:] * 0.2 + 0.05
    dn_scores = torch.randn((layers, batch_size, dn_queries, 3), generator=generator)
    dn_meta = {
        "dn_pos_idx": [torch.tensor([0]), torch.empty(0, dtype=torch.long)],
        "dn_num_group": 1,
    }

    losses = criterion(
        (boxes, scores),
        _mixed_batch(),
        dn_bboxes=dn_boxes,
        dn_scores=dn_scores,
        dn_meta=dn_meta,
        corner_logits=_corner_logits(layers=layers - 1),
        pre_boxes=boxes[0].detach().clone().requires_grad_(True),
        dn_corner_logits=_corner_logits(
            layers=layers,
            batch=batch_size,
            queries=dn_queries,
        ),
        dn_pre_boxes=dn_boxes[0].detach().clone().requires_grad_(True),
    )

    assert {
        "loss_fgl",
        "loss_fgl_aux",
        "loss_bbox_pre",
        "loss_giou_pre",
    }.issubset(losses)
    assert not {
        "loss_fgl_dn",
        "loss_fgl_aux_dn",
        "loss_bbox_pre_dn",
        "loss_giou_pre_dn",
    }.intersection(losses)
    assert {"loss_class_dn", "loss_bbox_dn", "loss_giou_dn"}.issubset(losses)


def test_empty_gt_losses_are_zero_finite_and_do_not_call_an_extra_matcher() -> None:
    layers = 2
    boxes, scores = _predictions(layers=layers)
    empty = _empty_matches()
    matcher = CountingMatcher(empty)
    criterion = FDRDetectionLoss(
        nc=3, use_vfl=True, fgl_weight=0.15, supervise_pre_boxes=True
    )
    criterion.matcher = matcher
    corners = _corner_logits(layers=layers - 1)
    pre_boxes = boxes[0].detach().clone().requires_grad_(True)

    losses = criterion(
        (boxes, scores),
        _empty_batch(),
        corner_logits=corners,
        pre_boxes=pre_boxes,
    )
    total = sum(losses.values())
    total.backward()

    assert matcher.calls == layers
    assert criterion.fgl_extra_match_calls == 0
    assert all(torch.isfinite(value) for value in losses.values())
    for key in ("loss_fgl", "loss_fgl_aux", "loss_bbox_pre", "loss_giou_pre"):
        torch.testing.assert_close(losses[key], torch.zeros_like(losses[key]))
    assert corners.grad is not None and torch.isfinite(corners.grad).all()
    assert pre_boxes.grad is not None and torch.isfinite(pre_boxes.grad).all()


def test_boundary_targets_produce_finite_fgl_backward() -> None:
    reference = torch.tensor(
        [[0.01, 0.01, 0.01, 0.01], [0.99, 0.99, 0.01, 0.01]],
        dtype=torch.float32,
    )
    targets_xyxy = torch.tensor(
        [[0.0, 0.0, 1.0, 1.0], [0.0, 0.0, 1.0, 1.0]],
        dtype=torch.float32,
    )
    left, wr, wl = bbox2distance(reference, targets_xyxy)
    logits = torch.randn((8, 33), requires_grad=True)
    quality = torch.ones(8)

    loss = adjacent_bin_fgl(logits, left, wl, wr, quality, avg_factor=2.0)
    loss.backward()

    assert torch.isfinite(loss)
    assert logits.grad is not None and torch.isfinite(logits.grad).all()
    assert torch.all((left >= 0) & (left < 32))


def test_fgl_requires_preliminary_boxes_as_detached_target_reference() -> None:
    boxes, scores = _predictions(layers=2)
    matches = _matches_with_one_positive()
    criterion = FDRDetectionLoss(nc=3, use_vfl=True, fgl_weight=0.15)

    with pytest.raises(ValueError, match="pre_boxes are required"):
        criterion(
            (boxes, scores),
            _mixed_batch(),
            normal_match_indices=[matches, matches],
            corner_logits=_corner_logits(layers=1),
        )


def test_pre_box_helper_is_optional() -> None:
    boxes, scores = _predictions(layers=1)
    matches = _matches_with_one_positive()
    criterion = FDRDetectionLoss(
        nc=3, use_vfl=True, fgl_weight=0.0, supervise_pre_boxes=False
    )

    losses = criterion(
        (boxes, scores),
        _mixed_batch(),
        normal_match_indices=[matches],
        pre_boxes=boxes[0].detach().clone().requires_grad_(True),
    )

    assert not any("pre" in key for key in losses)


def test_stock_plus_fgl_is_the_explicit_extension_entrypoint() -> None:
    boxes, scores = _predictions(layers=1)
    matches = _matches_with_one_positive()
    criterion = FDRDetectionLoss(
        nc=3, use_vfl=True, fgl_weight=0.0, supervise_pre_boxes=False
    )

    losses = criterion.stock_plus_fgl(
        (boxes, scores),
        _mixed_batch(),
        normal_match_indices=[matches],
    )

    assert {"loss_class", "loss_bbox", "loss_giou"}.issubset(losses)


@pytest.mark.parametrize("bad_layers", [0, 2])
def test_supplied_assignment_count_must_equal_prediction_layers(bad_layers: int) -> None:
    boxes, scores = _predictions(layers=3)
    matches = [_matches_with_one_positive()] * bad_layers
    criterion = FDRDetectionLoss(nc=3, use_vfl=True, fgl_weight=0.0)

    with pytest.raises(ValueError, match="one normal assignment per prediction layer"):
        criterion(
            (boxes, scores),
            _mixed_batch(),
            normal_match_indices=matches,
        )
